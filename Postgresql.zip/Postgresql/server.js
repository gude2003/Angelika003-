import express from "express";
import bodyParser from "body-parser";
import { dirname } from "path";
import path from 'path';
import { fileURLToPath } from "url";
import pkg from "pg";

const __dirname = dirname(fileURLToPath(import.meta.url));

const app = express();
const port = 3000;
const { Pool } = pkg;

//PostgreSQL connection
const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "Login",
    password: '1234',
    port:5432,
})

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

let loginAttempts = {};
const MAX_ATTEMPTS = 3;
const LOCK_TIME = 10 * 1000; // 10 seconds

app.get("/", (req,res) => {
    res.sendFile(__dirname + "/public/login.html");
});

app.post("/login", async (req, res) => {
    const { username, password } = req.body;

    try {
        const result = await pool.query('SELECT * FROM users WHERE username = $1', [username]);
        const user = result.rows[0];

        //Check if the user is locked out
        if (loginAttempts[username] && loginAttempts[username].attempts >= MAX_ATTEMPTS) {
            const timeLeft = LOCK_TIME - (Date.now() - loginAttempts[username].loginAttempt);
            if (timeLeft > 0) {
                return res.status(403).send(`Too many attempts. Try again in ${Math.ceil(timeLeft / 1000)} seconds.`);
            } else {
                // Reset attempts after lock time
                loginAttempts[username] = { attempts: 0};
            }
        }

        if (user && user.password === password) {
            // Successful Login
            loginAttempts[username] = { attempts: 0 };
            res.sendFile(__dirname + "/public/table.html");
        } else {
            // Failed login
            if (!loginAttempts[username]) {
                loginAttempts[username] = { attempts: 0};
            }
            loginAttempts[username].attempts++;
            loginAttempts[username].loginAttempts = Date.now();

            const attemptsLeft = MAX_ATTEMPTS - loginAttempts[username].attempts;

            if (loginAttempts[username].attempts >= MAX_ATTEMPTS) {
                return res.status(403).send('Max attempts reached. Please wait 10 seconds.');
            }

            res.status(401).send(`Invalid credentials. Attempts left: ${attemptsLeft}`);
        }
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal server error');
    }

});
// User management routes

//get tale values
app.get("/users", async (req, res) =>{
    try{
      const result = await pool.query('SELECT username, password FROM users;');
      res.json(result.rows);
    } catch (error){
      console.error(error);
      res.status(500).send('Internal server error');
    }
  });
//add user
app.post("/users", async (req, res) => {
    console.log(req.body);
    const { username, password } = req.body;
    try {
        await pool.query('INSERT INTO users (username, password) VALUES ($1, $2)', [username,password]);
        res.status(201).send('User added');
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal server error');
    }
});

// Update on user
app.put("/users/:username", async (req, res) => {
    console.log(req.params.username);
    console.log(req.body);
    const username = req.params.username;
    const { password } = req.body;
    try {
        const result = await pool.query('UPDATE users SET password = $1 WHERE username = $2', [password, username]);

        if(result.rowCount == 0){
            return res.status(404).send('User not found');
        }

        res.send('User updated successfully');
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal server error');
    }
    });

    //delete users
    app.delete("/users/:username", async (req, res) => {
        const { username } = req.params;
        try {
            await pool.query('DELETE FROM users WHERE username = $1', [username]);
            res.send('User deleted');
        } catch (error) {
            console.error(error);
            res.status(500).send('Internal server error');
        }
        });

        app.listen(port, () => {
            console.log(`Listening on port ${port}`);
        });