let user =[];
async function fetchUsers() {
    try {
        const response = await fetch('/users');
        if (response.ok) {
            users = await response.json();
            updateUserTable();
            //populateDeleteDropdown();
        } else {
            console.error('Failed to fetch users');
        }
    } catch (error) {
        console.error('Error fetching users:', error);
    }
}

function updateUserTable() {
    const userTableBody = document.getElementById('userTable').getElementsByTagName('tbody')[0];
    userTableBody.innerHTML = '';
    users.forEach((user) => {
        const row = userTableBody.insertRow();
        const usernameCell = row.insertCell(0);
        const passwordCell = row.insertCell(1);
        usernameCell.innerText = user.username;
        passwordCell.innerText = user.password;
    });
}

//add user
document.getElementById('add').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('addUsername').value;
    const password = document.getElementById('addpassword').value;

    const response = await fetch('/users', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
    });

    const message = await response.text();
    alert(message);
    document.getElementById('add').reset();
    fetchUsers();
});

