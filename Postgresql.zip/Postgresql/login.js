async function handleLogin(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    //send login request
    const response = await fetch('/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });
    if (response.ok) {
      localStorage.setItem('username', username);
      window.location.href = '/secret.html';
    } else {
      const message = await response.text();
      alert(message);
    }
  }